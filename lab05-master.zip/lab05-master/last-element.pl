% Find the last element of a list



 % TODO: Implement my_last/2
my_last(L, X) :- length(L, Y), Y1 is Y-1, nth0(Y1, L, X).

% Tests
:- my_last([a, b, c, d], X), display(X), nl. 
:- my_last([a], X), display(X), nl. 

