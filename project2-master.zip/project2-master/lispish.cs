using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;

public class LispishParser
{
    // needed to make this to make it easier to pass values
    static int index = 0;
  
    public enum Symbol {
      INVALID,
      LITERAL,
      REAL,
      INT,
      STRING,
      ID,
      Program,
      SExpr,
      List,
      Seq,
      Atom
    }
  
    public class Node
    {
        public Symbol Token;
        public string Text;
        public List<Node> Children;
      
        public Node(Symbol token, string text) {
          Token = token;
          Text = text;
          Children = new List<Node>();
        }

        public Node(Symbol token, string text, List<Node> children) {
          Token = token;
          Text = text;
          Children = children;
        }
      
        public void Print(string prefix = "")
        {
          if (Children.Count == 0) {
            Console.WriteLine($"{prefix + Token,-40} {Text}");  // only print text if leaf node
          } else {
            Console.WriteLine($"{prefix + Token,-40}"); 
            foreach (Node node in Children) {
              node.Print(prefix + "  ");
            }
          }
        }
    }

    static public List<Node> Tokenize(String src)
    {
        Regex litReg = new Regex(@"[\\(\\)]");
        Regex realReg = new Regex(@"(?>\+|-)?[0-9]*\.[0-9]+");
        Regex intReg = new Regex(@"(?>\+|-)?[0-9]+");
        Regex strReg = new Regex(@"""(?>\\""|.)*""");
        Regex idReg = new Regex(@"[^\s""\(\)]+");
        Regex wsReg = new Regex(@"\s");

        List<Node> tknList = new List<Node>();

        while (src.Length > 0) {
          // check for all possible matches
          Match litMatch = litReg.Match(src);
          Match realMatch = realReg.Match(src);
          Match intMatch = intReg.Match(src);
          Match strMatch = strReg.Match(src);
          Match idMatch = idReg.Match(src);
          Match wsMatch = wsReg.Match(src);
          
          if (wsMatch.Success && wsMatch.Index == 0) {  // this skips over whitespace at start
            src = wsReg.Replace(src, "", 1);
          } else if (litMatch.Success && litMatch.Index == 0) {  // match literal at start
            //Console.WriteLine("Found Literal");
            src = litReg.Replace(src, "", 1);
            tknList.Add(new Node(Symbol.LITERAL, litMatch.Value));
          } else if (realMatch.Success && realMatch.Index == 0) { // match real at start
            //Console.WriteLine("Found Real");
            src = realReg.Replace(src, "", 1);
            tknList.Add(new Node(Symbol.REAL, realMatch.Value));
          } else if (intMatch.Success && intMatch.Index == 0) { // match int at start
            //Console.WriteLine("Found Integer");
            src = intReg.Replace(src, "", 1);
            tknList.Add(new Node(Symbol.INT, intMatch.Value));
          } else if (strMatch.Success && strMatch.Index == 0) { // match string at start
            //Console.WriteLine("Found String");
            src = strReg.Replace(src, "", 1);
            tknList.Add(new Node(Symbol.STRING, strMatch.Value));
          } else if (idMatch.Success && idMatch.Index == 0) { // match id at start
            //Console.WriteLine("Found ID");
            src = idReg.Replace(src, "", 1);
            tknList.Add(new Node(Symbol.ID, idMatch.Value));
          } else { // found thing not supposed to be there
            //Console.WriteLine("Found Invalid");
            throw new Exception();
          }
        }              
        return tknList;
    }

    static public void AdvanceIndex() {
      // this method ensures all parse methods are on the same page
      // as far as the index value is concerned
      // and that is all it does
      index++;
    }
  
    static public Node ParseProgram(Node[] tokens) {
      // make new program node
      Node program = new Node(Symbol.Program, "program");
      // add SExpr as long as not at end of array
      while (index < tokens.Length) {
        program.Children.Add(ParseSExpr(tokens));
      }
      index = 0;  // reset just in case
      return program;
    }

    static public Node ParseSExpr(Node[] tokens) {
      // new node with empty child list
      Node sexpr = new Node(Symbol.SExpr, "sexpr");
      if (tokens[index].Text == "(") {
        // add list if at (
        sexpr.Children.Add(ParseList(tokens));
      } else {
        // add atoms otherwise
        sexpr.Children.Add(ParseAtom(tokens));
      }
      return sexpr;
    }

    static public Node ParseList(Node[] tokens) {
      Node listNode = new Node(Symbol.List, "list");
      listNode.Children.Add(tokens[index]); // add first token (
      AdvanceIndex();  // next index
      if (tokens[index].Text == ")") {  // if the list is just empty ()
        listNode.Children.Add(tokens[index]);  // add and move on
        AdvanceIndex();
      } else {
        // if items found in list, add them
        listNode.Children.Add(ParseSeq(tokens));
        // if not at ) when done, a ) is missing
        // so throw an exception
        if (tokens[index].Text != ")") {
          throw new Exception();
        }
        // add current token if passed
        listNode.Children.Add(tokens[index]);
        // advance index, and list is done
        AdvanceIndex();       
      }
      return listNode;
    }

    static public Node ParseSeq(Node[] tokens) {
      // new node with empty child list
      Node seq = new Node(Symbol.Seq, "seq");

      // add SExpr with current token
      seq.Children.Add(ParseSExpr(tokens));
      // add seq to list only if not )
      if (tokens[index].Text != ")") {
        seq.Children.Add(ParseSeq(tokens));
      }
      return seq;
    }

    static public Node ParseAtom(Node[] tokens) {
      // new atom node
      Node atom = new Node(Symbol.Atom, "atom");
      // add current node to child list, advance index, return
      atom.Children.Add(tokens[index]);
      AdvanceIndex();
      return atom;
    }
  
    static public Node Parse(Node[] tokens)
    {
        // give it to next parse program
        Node parsed = ParseProgram(tokens);
        return parsed;
    }

    static private void CheckString(string lispcode)
    {
        try
        {
            Console.WriteLine(new String('=', 50));
            Console.Write("Input: ");
            Console.WriteLine(lispcode);
            Console.WriteLine(new String('-', 50));

            Node[] tokens = Tokenize(lispcode).ToArray();

            Console.WriteLine("Tokens");
            Console.WriteLine(new String('-', 50));
            foreach (Node node in tokens)
            {
                Console.WriteLine($"{node.Token,-20}: {node.Text}");
            }
            Console.WriteLine(new String('-', 50));

            Node parseTree = Parse(tokens);

            Console.WriteLine("Parse Tree");
            Console.WriteLine(new String('-', 50));
            parseTree.Print();
            Console.WriteLine(new String('-', 50));
        }
        catch (Exception)
        {
            Console.WriteLine("Threw an exception on invalid input.");
        }
    }


    public static void Main(string[] args)
    {
        //Here are some strings to test on in 
        //your debugger. You should comment 
        //them out before submitting!

        // CheckString(@"(define foo 3)");
        // CheckString(@"(define foo ""bananas"")");
        // CheckString(@"(define foo ""Say \\""Chease!\\"" "")");
        // CheckString(@"(define foo ""Say \\""Chease!\\)");
        // CheckString(@"(+ 3 4)");      
        // CheckString(@"(+ 3.14 (* 4 7))");
        // CheckString(@"(+ 3.14 (* 4 7)");

        CheckString(Console.In.ReadToEnd());
    }
}

