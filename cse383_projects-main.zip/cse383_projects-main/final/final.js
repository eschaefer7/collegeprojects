/* Copyright 2021 Eddie Schaefer
* CSE 383 Final Project- JavaScript Portion
* This file is the JavaScript used to enable
* all the different functions needed for the project
* using ajax to call the relevant APIs and methods
* and has some minor validation to be used on the
* history search page.
*/

const routeURL = "http://www.mapquestapi.com/directions/v2/route";
const phpURL = "http://schaefep.aws.csi.miamioh.edu/final.php";
const elevURL = "http://open.mapquestapi.com/elevation/v1/chart";
const api_key = "g3O7cGgyr9JvlxV5WLavruXHneGrjGJ3";

// Some basic things that need to be done:
// Set onclick functions for buttons
// Hide error div (for history search page)
$(document).ready(function (){
  $("#submitBtn").on("click", getMap);
  $("#searchBtn").on("click", validateSearch);
  $("#errDiv").hide();
});

// This function validates input entered for a search history lookup
function validateSearch() {
  // hide the div that is going to hold the error
  $("#errDiv").hide();

  // the patterns to be used in checking the date and number of lines
  var datePtn = /^[0-9]{2}|[0-9]{2}|[0-9]{4}$/;
  var numPtn = /^[0-9]+$/;
  
  // get the values from the input fields
  var date = $("#dateField").val();
  var num = $("#lineField").val();
  
  // check the date and number inputs
  var dateGood = datePtn.test(date);
  var numGood = numPtn.test(num);

  // base text to be used for error display
  var errText = "Invalid or missing data in fields:</br>";

  // if the date is not good, add that to the error
  if (!dateGood) {
    errText = errText + "Date</br>";
  }

  // if the number is not good, add that to the error
  if (!numGood) {
    errText = errText + "Number of Lines";
  }

  // if either one is not good, add the error text
  // and display the error message
  if (!dateGood || !numGood) {
    $("#errDiv").html(errText);
    $("#errDiv").show();
  }
  
  // if both inputs are good, go ahead with search
  if (dateGood && numGood) {
    getHistory();
  }
}

// function used for getting the maps from the route API
function getMap() {
  // get the value from the field in the from section
  var addressF = $("#addressF").val();

  // get the value from the field in the to section
  var addressT = $("#addressT").val();
  
  // these will be used for data needed for the other APIs
  var from;
  var to;
  var locations;
  var latLngs = [];
  var sensor;
  var response;
  
  // initialize the data for the from and to locations
  from = {"from":addressF};
  to = {"to":addressT};
  // stringify the data to be used in the initial route API call
  from = JSON.stringify(from);
  to = JSON.stringify(to);

  $.ajax({
    url: routeURL,
    data: {key:api_key,from:addressF,to:addressT}
  }).done(function(resp){
    // clear the route div in advance
    $("#routeDiv").html("");

    // if the request went through and was good
    if (resp.info.statuscode === 0) {
      // initialize the locations object with the location data
      locations = {"from":from,"to":to};
      // get the lat long pairs to be used for the elevation API
      for (let i = 0; i < resp.route.locations.length; i++) {
        latLngs.push(resp.route.locations[i].latLng.lat);
        latLngs.push(resp.route.locations[i].latLng.lng);
      }
      // initialize sensor
      sensor = resp.info.statuscode;

      // add each maneuver's narrative and thumbnail to the div
      for (let i = 0; i < resp.route.legs[0].maneuvers.length; i++) {
        // get the narrative in its own variable
        let narr = resp.route.legs[0].maneuvers[i].narrative;
      
        // the last narrative has no map URL, so this check is needed
        if (i < resp.route.legs[0].maneuvers.length - 1) {
          // initialize a map URL variable if needed
          let map = resp.route.legs[0].maneuvers[i].mapUrl;
          // append a narrative and map thumbnail in a row div
          $("#routeDiv").append("<div class='row narrDiv'><div class='col-md-6 align-self-center'><p>" + narr + "</p></div><div class='col-md-6'><img src='" + map + "'</img></div></div>");
        } else {
          // otherwise just append the last narrative
          $("#routeDiv").append("<div class='row'><div class='col-12'><p>" + narr + "</p></div></div>");
        }
      }

      // initialize a response object for later
      response = {"routeResp":resp,"chartResp":""};

      // call the chart API, passing all the data into it
      // this data is needed to sequentially call the insertData
      // method once all the data is added into objects
      getChart(locations, sensor, response, latLngs);
    } else {  // if request went through, but was not good
      // starter string for error text
      var errText = "Error(s) getting route:</br>";
      
      // add each error message to it
      for (let i = 0; i < resp.info.messages.length; i++) {
        errText = errText + resp.info.messages[i] + "</br>";
      }

      // add an error div to the result div
      $("#routeDiv").append("<div class='row alert alert-danger'><div class='col-md-12'>"
        + errText + "</div></div>");
    }
  }).fail(function(error){
    console.log(error.statusText);
  });

}

// This function attempts to insert data into the database
// via the setLookup method in final.php
function insertData(locations, sensor, response) {
  $.ajax({
    // set the URL, method, and data to be sent
    url: phpURL,
    method: "post",
    // locations entered as search go into location
    // value field is used to hold responses from both
    // the route API and the elevation chart API
    data: {method:"setLookup",location:locations,sensor:sensor,value:response} 
  }).done(function(data){
    // say it was successful if it succeeded
    console.log("insert of data successful");
  }).fail(function(error){
    console.log("insert of data unsuccessful");
  });
}

// This function uses the lat long pair data from the initial route API call
// to call the elevation chart API, and then calls the insertData method
// to insert the search into the database on a successful call.
function getChart(locations, sensor, response, latLngs) {
  $.ajax({
    url: elevURL,
    method: "get",
    // specify the format of the data being entered, width and height
    // and provide the lat long pairs to be used for the chart
    data: {"key":api_key,"shapeFormat":"raw","width":400,"height":300,"latLngCollection":latLngs.toString()}
  }).done(function(){
    // if successful, add the chart to the elevation chart div
    // and store the URL to the chart in the response object
    $("#mapRouteElev").html("<img src='" + this.url + "'></img>");
    response.chartResp = this.url;

    // now that all data is present, insert it into the database
    insertData(JSON.stringify(locations), sensor, JSON.stringify(response));
  }).fail(function(error){
    // log the error if one occurred
    console.log(error.statusText);

    // display error, make this the chart response as well
    $("#mapRouteElev").html("Unable to get elevation chart with supplied data.");
    response.chartResp = "Unable to get elevation chart with supplied data.";
    insertData(JSON.stringify(locations), sensor, JSON.stringify(response));
  });
}

// This function calls the getLookup method from the php file
// and uses the returned data to show results from a given day
// of searches given a maximum number of lines
function getHistory() {
  // get the data into variables for later
  var dateField = $("#dateField").val();
  var numLines = $("#lineField").val();
  $.ajax({
    // call the getLookup method
    url: phpURL,
    method: "get",
    data: {method:"getLookup",date:dateField}
  }).done(function(data) {
    // clear the table body just in case
    $("#tBody").html("");

    // append a row of data for each entry in the result
    for (let i = 0; i < numLines && i < data.result.length; i++) {
      // certain data was stringified at some point, and now
      // it has to be parsed to be used properly.
      var parsedValue = JSON.parse(data.result[i].value);
      var parsedLoc = JSON.parse(data.result[i].location);
      var parsedFrom = JSON.parse(parsedLoc.from);
      var parsedTo = JSON.parse(parsedLoc.to);

      // get the date and locations to be displayed in the table
      var lineDate = data.result[i].date;
      var lineFrom = parsedFrom.from;
      var lineTo = parsedTo.to;

      // get the number of maneuvers done for the route
      var lineNum = parsedValue.routeResp.route.legs[0].maneuvers.length;
      
      // this variable is used for storing the HTML of a route div
      // in an invisible div contained in a button for the row.
      var btnHTML = "";
       
      // for each entry in the route of the current entry
      for (let j = 0; j < lineNum; j++) {
        // this is essentially the exact same process used in building
        // the initial route div, for the directions page
        let narr = parsedValue.routeResp.route.legs[0].maneuvers[j].narrative;
        if (j < lineNum - 1) {
          var map = parsedValue.routeResp.route.legs[0].maneuvers[j].mapUrl;
          // this substring is necessary for the method to work
          // since by default the mapURL has a session id as a parameter.
          // the session id is not required to view a map, but not omitting it
          // makes every map from a session > 30 minutes old unable to be
          // viewed. the session parameter in the URL is 50 chars long.
          map = map.substring(0, map.length - 50);
          btnHTML = btnHTML + "<div class='row narrDiv'><div class='col-12 align-self-center'><p>" + narr + 
            "</p><div><img src='" + map + "'</img></div></div></div>";
        } else {
	  btnHTML = btnHTML + "<div class='row'><div class='col-12'><p>" + narr + "</p></div></div>";
        }
      }

      // append an elevation div to the end of the HTML
      btnHTML = btnHTML + "<div class='row'><div class='col-12' id='mapRouteElev'><img src='" + parsedValue.chartResp + "'></img></div></div>";

      // append a row of table data, hiding the button HTML in the
      // button inside a div with display set to none
      $("#tBody").append("<tr><td>" + lineDate + "</td><td>" + 
        lineFrom + "</td><td>" + lineTo + "</td><td>" + lineNum + 
        "</td><td><button type='button' class='viewBtn btn btn-info'>View<div class='d-none'>" 
        + btnHTML + "</div></button></td></tr>");
    }

    // set a function for when a view button is clicked
    $(".viewBtn").on("click", function (){ 
      // set the HTML of the details div to the HTML hidden in the button
      $("#viewDiv").html($(this).find("div").html());
      // if any view button appears clicked, make it appear unclicked
      $(".viewBtn.btn-outline-info").toggleClass("btn-info btn-outline-info");
      // make this button appear clicked
      $(this).toggleClass("btn-info btn-outline-info");
    });
  }).fail(function(error) {
    console.log(error.statusText);
  });
}
