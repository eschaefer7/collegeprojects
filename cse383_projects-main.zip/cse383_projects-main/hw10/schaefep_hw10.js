/*
* Copyright 2021 Eddie Schaefer
* CSE 383 HW 10
* Javascript Portion: Handling basic addition, subtraction,
* multiplication, and division using an API.
*/

// string vars for the parts of the URL that never change
var URL = "https://api.clearllc.com/api/v2/math/";
var apiKey = "bed859b37ac6f1dd59387829a18db84c22ac99c09ee0f5fb99cb708364858818";

function addNum() {
  a=$.ajax({
    // send get request to the Add API
    url: URL + 'Add',
    data: {api_key: apiKey, n1: $("#num1").val(), n2: $("#num2").val()},
    method: "GET"
  }).done(function(data) {
    // get the values, put them in the result area below the input area
    num1 = $("#num1").val();
    num2 = $("#num2").val();
    // addition result: num1 + num2 = result
    $("#resultCol").html("<p>Addition Result: " + num1 + " + " + num2 + " = " + data.result + "</p>");
  }).fail(function(error) {
    $("#resultCol").html("<p>" + error.statusText + "</p>");
  });
}

function subtractNum() {
  // send get request to the Subtract API
  a=$.ajax({
    url: URL + 'Subtract',
    // send the API key and input numbers
    data: {api_key: apiKey, n1: $("#num1").val(), n2: $("#num2").val()},
    method: "GET"
  }).done(function(data) {
    // get values and display result below input area
    num1 = $("#num1").val();
    num2 = $("#num2").val();
    // subtraction result: num1 - num2 = result
    $("#resultCol").html("<p>Subtraction Result: " + num1 + " - " + num2 + " = " + data.result + "</p>");
  }).fail(function(error) {
    $("#resultCol").html("<p>" + error.statusText + "</p>");
  });
}

function multiplyNum() {
  // send get request to the Multiply API
  a=$.ajax({
    url: URL + 'Multiply',
    // send the API key and input numbers
    data: {api_key: apiKey, n1: $("#num1").val(), n2: $("#num2").val()},
    method: "GET"
  }).done(function(data) {
    // get values and display result below input area
    num1 = $("#num1").val();
    num2 = $("#num2").val();
    // multiplication result: num1 x num2 = result
    $("#resultCol").html("<p>Multiplication Result: " + num1 + " x " + num2 + " = " + data.result + "</p>");
  }).fail(function(error) {
    $("#resultCol").append("<p>" + error.statusText + "</p>");
  });
}

function divideNum() {
  // send get request to the Divide API
  a=$.ajax({
    url: URL + 'Divide',
    // this is where the api key and input numbers get sent
    data: {api_key: apiKey, n1: $("#num1").val(), n2: $("#num2").val()},
    method: "GET"
  }).done(function(data) {
    // get values and display below input area
    num1 = $("#num1").val();
    num2 = $("#num2").val();
    // division result: num1 / num2 = result
    $("#resultCol").html("<p>Division Result: " + num1 + " / " + num2 + " = " + data.result + "</p>");
  }).fail(function(error) {
    // note: this exists specifically for division to handle division by 0.
    // it would not let me read the error sent as a response from the API
    // so I had to tell it to send a divide by 0 error if num2 was 0.
    var errorText = error.statusText;
    if ($("#num2").val() == 0) {
      errorText = "Divide by 0 error.";
    }
    $("#resultCol").html("<p>" + errorText + "</p>");
  });
}
