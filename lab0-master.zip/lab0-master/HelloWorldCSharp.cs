using System;

class HelloWorld {
	static void Main(string[] args){
		Console.WriteLine("Hello, world!");			
	}
}
