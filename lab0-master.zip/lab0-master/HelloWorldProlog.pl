:- writeln("Hello, world!"), halt.
