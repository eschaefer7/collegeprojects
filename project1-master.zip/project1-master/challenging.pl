 
%% I will not accept a submission with the T0D0 comments left in place!

url("https://logic.puzzlebaron.com/pdf/Y809MT.pdf").

solution([[184, 'Ollie', '5th', 'Lindy'],
	  [187, 'Judith', '4th', 'Twist'],
	  [190, 'Lillian', '3rd', 'Foxtrot'],
	  [193, 'Darla', '1st', 'Samba'],
	  [196, 'Patti', '9th', 'Charleston']]).

names(['Ollie', 'Judith', 'Lillian', 'Darla', 'Patti']).
places(['5th', '4th', '3rd', '1st', '9th']).
dances(['Lindy', 'Twist', 'Foxtrot', 'Samba', 'Charleston']).

solve(T) :-
	T = [[184, N1, P1, D1],
	     [187, N2, P2, D2],
	     [190, N3, P3, D3],
	     [193, N4, P4, D4],
	     [196, N5, P5, D5]],
	names(Names), permutation([N1, N2, N3, N4, N5], Names),
	clue7(T),  % N _ _
	dances(Dances), permutation([D1, D2, D3, D4, D5], Dances),
	clue8(T),  % N _ D
        clue3(T),  % N _ D
	places(Places), permutation([P1, P2, P3, P4, P5], Places),
	clue2(T),  % N P D
        clue4(T),  % N P D
        clue9(T),  % N P D
	clue6(T),  % N P _
	clue5(T),  % _ P D
        clue1(T),  % _ P D
        clue10(T). % _ _ D

% The person who danced fourth scored 3 points lower than the performer who did the foxtrot
clue1(T) :- 
	member([P1, _, '4th', _], T),
	member([P2, _, _, 'Foxtrot'], T),
	P1 =:= P2-3.


% Of the dancer who did the foxtrot and the dancer that scored 196 points, one was Patti and the other danced third
clue2(T) :- 
	member([196, N1, P1, _], T),
	member([_, N2, P2, 'Foxtrot'], T),
	(N1 = 'Patti', P2 = '3rd'; N2 = 'Patti', P1 = '3rd').


% Judith did not dance the Lindy
clue3(T) :- 
	not(member([_, 'Judith', _, 'Lindy'], T)).

% Neither the person that scored 196 points nor the dancer who performed fifth was Judith
clue4(T) :-
	member([Po, 'Judith', P, _], T),
	not(member([196, _, '5th', _], T)),
	Po \= 196,
	P \= '5th'.

% The dancer who performed fourth scored 9 points lower than the performer who did the charleston
clue5(T) :-
	member([Po1, _, _, 'Charleston'], T),
	member([Po2, _, '4th', _], T),
	Po2 =:= Po1-9.

% Judith didn't perform first
clue6(T) :-
	not(member([_, 'Judith', '1st', _], T)).

% Darla didn't finish with 184 points
clue7(T) :-
	not(member([184, 'Darla', _, _], T)).

% Lillian scored 3 points lower than the dancer who did the samba
clue8(T) :-
	member([P1, _, _, 'Samba'], T),
	member([P2, 'Lillian', _, _], T),
	P2 =:= P1-3.

% Of Patti and the dancer who performed first, one performed the charleston and the other performed the samba
clue9(T) :- 
	member([_, 'Patti', _, D1], T),
	member([_, _, '1st', D2], T),
	(D1 = 'Charleston', D2 = 'Samba';
	D1 = 'Samba', D2 = 'Charleston').

% The person that scored 187 points didn't perform the foxtrot
clue10(T) :-
	not(member([187, _, _, 'Foxtrot'], T)).

check :- 
	% Confirm that the correct solution is found
	solution(S), (solve(S); not(solve(S)), writeln("Fails Part 1: Eliminates the correct solution"), fail),
	% Make sure S is the ONLY solution 
	not((solve(T), T\=S, writeln("Failed Part 2: Does not eliminate:"), print_table(T))),
	writeln("Found 1 solutions").

print_table([]).
print_table([H|T]) :- atom(H), format('~|~w~t~20+', H), print_table(T). 
print_table([H|T]) :- is_list(H), print_table(H), nl, print_table(T). 


% Show the time it takes to conform that there are no incorrect solutions
checktime :- time((not((solution(S), solve(T), T\=S)))).

