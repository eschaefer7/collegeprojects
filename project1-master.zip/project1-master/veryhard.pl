

%% I will not accept a submission with the T0D0 comments left in place!

url("https://logic.puzzlebaron.com/pdf/N430VJ.pdf").

%	  Distance (miles), Car, Speed (MPH), Team
solution([[525, 'Awick', 74, 'Bennington'],
	  [550, 'Yamahana', 75, 'Alby College'],
	  [575, 'Zenmoto', 65, 'Varseyton'],
	  [600, 'Garusky', 62, 'Darbyshire'],
	  [625, 'Cober', 72, 'Mersey Tech'],
	  [650, 'Poltris', 69, 'Trebus State']]).

cars(['Awick', 'Yamahana', 'Zenmoto', 'Garusky', 'Cober', 'Poltris']).
speeds([74, 75, 65, 62, 72, 69]).
teams(['Bennington', 'Alby College', 'Varseyton', 'Darbyshire', 'Mersey Tech', 'Trebus State']).

solve(T) :-
	T = [[525, C1, S1, T1],
	     [550, C2, S2, T2],
	     [575, C3, S3, T3],
	     [600, C4, S4, T4],
	     [625, C5, S5, T5],
	     [650, C6, S6, T6]],
	cars(Cars), permutation([C1, C2, C3, C4, C5, C6], Cars),
	clue4(T),  % C _ _
	clue8(T),  % C _ _
	teams(Teams), permutation([T1, T2, T3, T4, T5, T6], Teams),
	clue5(T),  % C _ T
	speeds(Speeds), permutation([S1, S2, S3, S4, S5, S6], Speeds),
	clue1(T),  % C S T
	clue3(T),  % C S T
	clue7(T),  % C S T
	clue12(T), % C S T
	clue6(T),  % C S _
        clue2(T),  % C S _
	clue11(T), % _ S T
	clue9(T),  % _ _ T
	clue10(T). % _ _ T

% of the car that drove for 650 miles and the Zenmoto, one had a high speed of 65 mph
% and the other was built by the Trebus State team.
clue1(T) :- 
	member([650, _, S1, T1], T),
	member([_, 'Zenmoto', S2, T2], T),
	(S1 = 65, T2 = 'Trebus State' ; 
	S2 = 65, T1 = 'Trebus State').


% the Awick drove 25 fewer miles than the automobile with a high speed of 75 mph
clue2(T) :-
	member([D1, 'Awick', _, _], T),
	member([D2, _, 75, _], T),
	D1 =:= D2-25.


% the Mersey Tech team's car was either the car that drove for 625 miles or the Garusky.
clue3(T) :- 
	member([625, _, _, T1], T),
	member([_, 'Garusky', _, T2], T),
	not(member([625, 'Garusky', _, _], T)),
	(T1 = 'Mersey Tech' ; T2 = 'Mersey Tech').


% the Zenmoto didn't drive for exactly 525 miles.
clue4(T) :-
	not(member([525, 'Zenmoto', _, _], T)).


% The Trebus State team's car drove 100 miles farther than the Yamahana.
clue5(T) :-
	member([D1, _, _, 'Trebus State'], T),
	member([D2, 'Yamahana', _, _], T),
	D1 =:= D2+100.


% The Poltris didn't have a high speed of exactly 62 mph.
clue6(T) :-
	not(member([_, 'Poltris', 62, _], T)).


% Of the car that drove 600 miles and the car with a high speed of 74 mph,
% one was built by the Bennington team and the other is the Garusky.
clue7(T) :-
	member([600, C1, _, T1], T),
	member([_, C2, 74, T2], T),
	not(member([_, 'Garusky', _, 'Bennington'], T)),
	(C1 = 'Garusky', T2 = 'Bennington' ;
	C2 = 'Garusky', T1 = 'Bennington').


% The Poltris didn't drive for exactly 625 miles.
clue8(T) :-
	not(member([625, 'Poltris', _, _], T)).


% The car that drove for 550 miles wasn't built by the Darbyshire team.
clue9(T) :-
	not(member([550, _, _, 'Darbyshire'], T)).


% Neither the Trebus State or the Darbyshire car drove for 625 miles.
clue10(T) :-
	not(member([625, _, _, 'Trebus State'], T)),
	not(member([625, _, _, 'Darbyshire'], T)).


% The Trebus State car was either the car with a high speed of 62 mph or a high speed of 69 mph.
clue11(T) :-
	member([_, _, S, 'Trebus State'], T),
	(S = 62 ; S = 69).


% Of the car with a high speed of 72 mph and the Varseyton car, one is the Zenmoto
% and the other drove for 625 miles.
clue12(T) :-
	member([D1, C1, 72, _], T),
	member([D2, C2, _, 'Varseyton'], T),
	not(member([625, 'Zenmoto', _, _], T)),
	not(member([_, _, 72, 'Varseyton'], T)),
	(D1 = 625, C2 = 'Zenmoto' ; 
	D2 = 625, C1 = 'Zenmoto').




check :- 
	% Confirm that the correct solution is found
	solution(S), (solve(S); not(solve(S)), writeln("Fails Part 1: Eliminates the correct solution"), fail),
	% Make sure S is the ONLY solution 
	not((solve(T), T\=S, writeln("Failed Part 2: Does not eliminate:"), print_table(T))),
	writeln("Found 1 solutions").

print_table([]).
print_table([H|T]) :- atom(H), format("~|~w~t~20+", H), print_table(T). 
print_table([H|T]) :- is_list(H), print_table(H), nl, print_table(T). 


% Show the time it takes to conform that there are no incorrect solutions
checktime :- time((not((solution(S), solve(T), T\=S)))).
