using System;
using System.Collections.Generic;

/**
 * This lab is the FIRST part of a parser lab.  This week we focus on lexing. 
 * Eventually, we will build a parser for a simple language that supports assignments
 *     var = expr
 * Typeing an expression by itself will display the value of the expression
 *
 * Tokens:
 *      ID:  Any letter followed be a sequence of letters and numbers
 *      REAL: An optional sign followed by a sequence of digits, optionally with single decimal point. 
 *      WS:  Whitespace (no tokens generated, this is skipped)
 *		LITS: (, ), =, +, -, *, /, ** 
 *Grammar:
 *      <stmt> ::= <assign> | <expr>
 *      <assign> ::= ID = <expr>
 *      <expr> ::= <term> | <term> + <expr> | <term> - <expr>
 *      <term> ::= <factor> | <factor> * <term> | <factor> / <term>
 *      <factor> ::= <base>**<factor> | <base>
 *      <base> := ID | NUM |  (<expr>)
 */
public class ExpressionParser {
    
    public enum Symbol
    {
		INVALID,
		ID,
		LITERAL,
		NUM,
		WS
    }

    /**
     * Represents a node in a parse tree. 
     * - Should keep track of the 'text' of the node (the substring under the node)
     * - Should keep track of the line and column where the node begins. 
     * - Should keep track of the children of the node in the parse tree
     * - should keep track of the Symbol (see the enum) corresponding to the node
     * - Tokens are leaf nodes (the array of children should be null)
     * - Needs a constructor with symbol, text, line, and column
     **/
    public class Node{
		public readonly string Text;
		public readonly int Line;
		public readonly int Column;
		public Symbol Token;
		private List<Node> children;
      
		public Node(Symbol token, string text, int line, int column) {
			Text = text;
			Line = line;
			Column = column;
			Token = token;
			children = new List<Node>();
		}	
    }

    /**
     * Generator for tokens. 
     * Use 'yield return' to return tokens one at a time.
     **/
    public static IEnumerable<Node> tokenize(System.IO.StreamReader src) 
    {
        int line = 1;
        int column = 1;
        System.Text.StringBuilder lexeme = new System.Text.StringBuilder();
		
		Symbol token = Symbol.INVALID; 
		int state = 0;
		
		while (!src.EndOfStream) {
      char c = (char)src.Peek();
      //Console.WriteLine($"State={state}  token={token}  lexeme={lexeme}  saw={c}");
      //Console.WriteLine($"Column={column}");
			switch (state) {
				case 0:
					if (c == '\n') {
            token = Symbol.WS;
            state = 0;
            //lexeme.Append(c);
            src.Read();
            column = 1;
            line++;
          } else if (char.IsWhiteSpace(c)){
            token = Symbol.WS;
            state = 0;
            src.Read();
            column++;
          } else if (c == '+' || c == '-') {
            token = Symbol.LITERAL;
            state = 1;
            lexeme.Append(c);
            src.Read();
            column++;
          } else if (char.IsDigit(c)) {
            token = Symbol.NUM;
            state = 2;
            lexeme.Append(c);
            src.Read();
            column++;
          } else if (c == '*') {
            token = Symbol.LITERAL;
            state = 4;
            lexeme.Append(c);
            src.Read();
            column++;
          } else if (char.IsLetter(c) || c == '_') {
            token = Symbol.ID;
            state = 6;
            lexeme.Append(c);
            src.Read();
            column++;
          } else if (c == '=' || c == '(' || c == ')') {
            token = Symbol.LITERAL;
            state = 5;
            lexeme.Append(c);
            src.Read();
            column++;
          } else {
            throw new Exception($"Invalid character '{c}' at line {line} column {column}");
          }
					break;	
				case 1:
          if (char.IsDigit(c)) {
            token = Symbol.NUM;
            state = 2;
            lexeme.Append(c);
            src.Read();
            column++;
          } else {
            yield return new Node(token, lexeme.ToString(), line, column);
            lexeme.Clear();
            token = Symbol.INVALID;
            state = 0;
          }
					break;
        case 2:
          if (char.IsDigit(c)) {
            token = Symbol.NUM;
            state = 2;
            lexeme.Append(c);
            src.Read();
            column += 1;
          } else if (c == '.') {
            token = Symbol.NUM;
            state = 3;
            lexeme.Append(c);
            src.Read();
            column++;
          } else {
            yield return new Node(token, lexeme.ToString(), line, column);
            lexeme.Clear();
            token = Symbol.INVALID;
            state = 0;
          }
					break;
        case 3:
          if (char.IsDigit(c)) {
            token = Symbol.NUM;
            state = 2;
            lexeme.Append(c);
            src.Read();
            column++;
          } else {
            yield return new Node(token, lexeme.ToString(), line, column);
            lexeme.Clear();
            token = Symbol.INVALID;
            state = 0;
          }
					break;
        case 4:
          if (c == '*') {
            token = Symbol.LITERAL;
            state = 5;
            lexeme.Append(c);
            src.Read();
            column++;
          } else {
            yield return new Node(token, lexeme.ToString(), line, column);
            lexeme.Clear();
            token = Symbol.INVALID;
            state = 0;
          }
          break;
        case 5:
          yield return new Node(token, lexeme.ToString(), line, column);
            lexeme.Clear();
            token = Symbol.INVALID;
            state = 6;
          break;
        case 6:
          if (char.IsLetter(c) || c == '_') {
            token = Symbol.ID;
            state = 6;
            lexeme.Append(c);
            src.Read();
            column++;
          } else if (char.IsDigit(c)) {
            token = Symbol.NUM;
            state = 2;
            lexeme.Append(c);
            src.Read();
            column++;
          } else {
            if (token != Symbol.INVALID)
            yield return new Node(token, lexeme.ToString(), line, column);
            lexeme.Clear();
            token = Symbol.INVALID;
            state = 0;
          }
          break;
			}
			//column = column + 1;
		}
		if (token != Symbol.INVALID && token != Symbol.WS)
		  yield return new Node(token, lexeme.ToString(), line, column);
    
    }

    public static void Main(string[] args){
		string src = "a+b";
    System.IO.Stream stream;
    bool testing = false;
        try {
          if (testing) {
			stream = new System.IO.MemoryStream(System.Text.Encoding.ASCII.GetBytes(src));
        } else {
			stream = Console.OpenStandardInput();
          }
            foreach (Node n in tokenize(new System.IO.StreamReader(stream))){
               Console.WriteLine($"{n.Token,-15}\t {n.Text}");
            }
        } catch (Exception e){
            Console.WriteLine(e.Message);
        }
    }
}
