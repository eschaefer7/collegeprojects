import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;


/**
 * 
 * Class Pair that combines a vertex number with a weight.
 * Used to pair destination city numbers with the distance of travel.
 * 
 */
class Pair {
	int first, second;
	/**
	 * Constructor for class Pair
	 * @param first - The destination city number.
	 * @param second - The distance to travel.
	 */
	public Pair(int first, int second) {
		this.first = first;
		this.second = second;
	}
}

public class Waypoint {
	
	
	static class Node {
		// VertexNumber is the city number
		int vertexNumber;
		// children is a list of all destinations and distances for each city.
		List<Pair> children;
		
		/**
		 * Base Constructor for class Node.
		 * default vertexNumber is 0, and empty list of children.
		 */
		Node() {
			this.vertexNumber = 0;
			this.children = new ArrayList<>();
		}
		/**
		 * Constructor for class Node.
		 * @param vertexNumber The number of the city we are initializing the node with.
		 */
		Node(int vertexNumber) {
			this.vertexNumber = vertexNumber;
			this.children = new ArrayList<>();
		}
		/**
		 * Adds a pair of children to the Node
		 * @param vNumber - Number of the destination city
		 * @param length - The weight of the edge.
		 */
		void add_child(int vNumber, int length) {
			Pair p = new Pair(vNumber, length);
			this.children.add(p);
		}
	}
	// [[cX, cY, cZ, cSN, cDN, length],
	//  [c2X, c2Y, c2Z, c2N, c2DN, length],
	// ]
	public static int findWaypointPath(int n, int[][] cities, int dst, int playerX, int playerY, int playerZ) {
		int shortest = -1;
		// Creates an ArrayList of Nodes.
		ArrayList<Node> verts = new ArrayList<>();
		int closest = locatePlayer(cities, playerX, playerY, playerZ);
		// This loop iterates throught flights and creates nodes with children.
		for (int[] arr : cities) {
			Node temp = new Node();
			temp.vertexNumber = arr[3];
			int index = checkVerts(verts, temp);
			// Check if the ArrayList contains the Node already or not.
			if (index == -1) {
				temp.add_child(arr[4], arr[5]);
				verts.add(temp);
			} else {
				// If the element already exists, we add another set of children to the Node.
				verts.get(index).add_child(arr[4], arr[5]);
			}
		}
		
		// Calls the dijkstra method to find the shortest paths.
		
		int[] distances = dijkstra(verts, closest, n);
		// If the path exists, then the cost of the flight changes.
		if (distances[dst] != Integer.MAX_VALUE) {
			shortest = distances[dst];
		}
		// Will return -1 if the flight does not exist.
		return shortest;
	}
	 
	/**
	 * Ideally this would use map data to get the users starting position.
	 * This method uses the players position in order to find the closest city and then
	 * find the shortest path from the starting city to the destination
	 */
	public static int locatePlayer(int[][] cities, int playerX, int playerY, int playerZ) {
		int[] min = {};
		int minDist = Integer.MAX_VALUE;
		for (int[] n : cities) {
			double dist = Math.sqrt((Math.pow((n[0] - playerX), 2) + Math.pow((n[1] - playerY), 2) + Math.pow(n[2] - playerZ, 2)));
			if (dist < minDist) {
				minDist = (int)dist;
				min = Arrays.copyOf(n, n.length);
			}
		}
		return min[3];
	}
	/**
	 * Helper method to check if the destination exists in the children of a Node
	 * @param children - List of Pairs
	 * @param dst - City number of the destination
	 * @return Index of the child if it exists in the list, otherwise -1.
	 */
	public static int checkChildren(List<Pair> children, int dst) {
		for (Pair p : children) {
			if (p.first == dst) {
				return p.second;
			}
		}
		return -1;
	}
	/**
	 * Helper method to check if a city exists in the list of Nodes.
	 * @param verts - List of Nodes
	 * @param vertex - The number of the city.
	 * @return The index of the Node, otherwise -1.
	 */
	public static int checkVerts(List<Node> verts, Node vertex) {
		for (Node v : verts) {
			if (v.vertexNumber == vertex.vertexNumber)
				return verts.indexOf(v);
		}
		return -1;
	}
	/**
	 * The Dijkstra shortest path algorithm to be able to get the shortest path of the starting city to
	 * any other city that is in the List of Nodes. 
	 * @param locations - List of Nodes
	 * @param playerx - The player's x coordinate
	 * @param playery - The player's y coordinate
	 * @param playerz - The player's z coordinate
	 * @param size - The amount of cities there are.
	 * @return Integer array containing the shortest distance to every other city.
	 */
	public static int[] dijkstra(List<Node> locations, int s, int size) {
		int[] distances = new int[size+1];
		boolean[] visited = new boolean[size+1];
		for (int i = 0; i <= size; i++) {
			visited[i] = false;
			distances[i] = Integer.MAX_VALUE;
		}
		distances[s] = 0;
		int current = s;
		Set<Integer> cities = new HashSet<>();
		while (current != size) {
			visited[current] = true;
			Node temp = new Node(current);
			for (int i = 0; i < locations.get(checkVerts(locations, temp)).children.size(); i++) {
				int v = locations.get(checkVerts(locations, temp)).children.get(i).first;
				if (visited[v])
					continue;
				cities.add(v);
				int alt = distances[current] + locations.get(
						checkVerts(locations, temp)).children.get(i).second;
				if (alt < distances[v]) {
					distances[v] = alt;
				}
				
			}
			cities.remove(current);
			if (cities.isEmpty())
				break;
			int minDist = Integer.MAX_VALUE;
			int index = 0;
			for (int a : cities) {
				if (distances[a] < minDist) {
					minDist = distances[a];
					index = a;
				}
			}
			current = index;
		}
		return distances;
	}
	
	public static void main(String[] args) {
		//int n, int[][] cities, int dst, int playerX, int playerY, int playerZ
		// [cX, cY, cZ, cSN, cDN, length]
		int n = 10;
		int[][] cities = {{10,4,0,2,1,7},
							{3,4,0,1,2,7},
						  {10,4,0,2,3,23},
						  {30,15,0,3,2,23},
						  {30,15,0,3,4,4},
						  {34,15,0,4,3,4},
						  {34,15,0,4,5,5},
						  {34,20,0,5,4,5},
						  {34,15,0,4,6,21},
						  {34,20,0,5,8,3},
						  {32,22,0,8,5,3},
						  {55,15,0,6,7,15},
						  {55,30,0,7,6,15},
						  {55,15,0,6,4,21},
						  {32,22,0,8,9,5},
						  {27,22,0,9,8,5},
						  {27,22,0,9,10,4},
						  {27,26,0,10,9,4}
							};
		int dst = 10, playerX = 22, playerY = 2, playerZ = 0;
		int shortest = findWaypointPath(n, cities, dst, playerX, playerY, playerZ);
		System.out.println(shortest);
	}

}
