% Implement the GCD algorithm using Prolog
% See https://en.wikipedia.org/wiki/Euclidean_algorithm#Implementations

% The recursive version of he Euclidean algorithm 
% for computing the GCD  is:
%
% function gcd(a, b)
%     if b = 0
%         return a
%     else
%         return gcd(b, a mod b)


%% TODO -- Define GCD here in Prolog here
	gcd(0, B, B).
	gcd(A, 0, A).
	gcd(0, 0, 0).
	gcd(A, B, X) :- B > A, B1 is B-A, gcd(A, B1, X).
	gcd(A, B, X) :- A > B, A1 is A-B, gcd(A1, B, X).
	gcd(A, B, X) :- A = B, X is A. 

%% Tests
:- gcd(8, 4, X), format('gcd of 8 and 4 is ~f~n', X).
:- gcd(105, 252, X), format('gcd of 105 and 252 is ~f~n', X).
